
#include<stdlib.h>
#include <stdio.h>

#define DIM 10


int main(int argc, char const *argv[])
{
    int x = 10;
    x = x/0;

    return 0;
}
